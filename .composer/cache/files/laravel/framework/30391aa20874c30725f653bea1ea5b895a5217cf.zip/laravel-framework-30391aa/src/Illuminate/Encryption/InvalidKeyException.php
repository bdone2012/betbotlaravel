<?php namespace Illuminate\Encryption;

use InvalidArgumentException;

class InvalidKeyException extends InvalidArgumentException {}
